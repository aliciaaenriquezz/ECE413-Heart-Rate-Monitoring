# ECE413-Heart-Rate-Monitoring
ECE413 Final Project
README must be written in markdown

The README should include:
Links to your server, the pitch, and demonstration videos.
Login credentials for an existing user account with recently collected data
ECE 513 only: Login credentials for a physician account
Create a 5-minute video that pitches the Heart Track project to potential investors (e.g., angel investors, VCs, Kickstarter, etc. See https://kickstarterguide.com/2012/06/13/examples-of-great-pitch-videos/ for examples of good pitch videos.)
