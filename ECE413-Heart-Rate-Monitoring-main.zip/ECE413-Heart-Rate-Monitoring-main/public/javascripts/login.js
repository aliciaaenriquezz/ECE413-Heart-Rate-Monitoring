

document.addEventListener("DOMContentLoaded", loadedHandler);

function loadedHandler() {
    var email = document.getElementById("email");
    var password = document.getElementById("password");
    var submitButton = document.getElementById("submit");
    submitButton.addEventListener("click", checkUsers);
}

/// ------ DATA BASE FUNCTIONS ------ ///
function checkUsers(){
    // data validation
    if ($('#email').val() === "") {
        window.alert("invalid email!");
        return;
    }

    let txdata = {
        email: $('#email').val()
    };

    $.ajax({
        url: '/users/search',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(txdata),
        dataType: 'json'
    })

    .done(function (data, textStatus, jqXHR) {
        if(data.length > 0){
            email.style.borderColor = "rgb(170, 170, 170)";
            email.style.borderWidth = "1px";
            checkPassword();
        } else {
            window.alert("This email does not exist.");
            email.style.borderColor = "red";
            email.style.borderWidth = "2px";
        }
    })
    .fail(function (data, textStatus, jqXHR) {
         window.alert("FAILURE javascripts/signup.js/isDuplicateEmails()");
    });
}

function checkPassword(){
    
}